-- / Easy School - Système gestion des Établissments Scolaires / -- 
-- / version 1.0 / --
-- / http://www.dabach.net / --

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT=0;
START TRANSACTION;
DROP TABLE absences;

CREATE TABLE `absences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(20) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `reason` varchar(50) NOT NULL,
  `note` mediumtext NOT NULL,
  `date` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




DROP TABLE administrator;

CREATE TABLE `administrator` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_index` varchar(30) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO administrator( `id`, `admin_index`, `username`, `password`, `email` ) VALUES
("1","27062040488","ramroum","0da95cfbe32d3027a906dedb4d0ec3e6","rami.aouinti@gmail.com");


DROP TABLE classes;

CREATE TABLE `classes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_name` varchar(50) NOT NULL,
  `class_numeric` varchar(30) NOT NULL,
  `class_note` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




DROP TABLE control;

CREATE TABLE `control` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `close_message` tinytext NOT NULL,
  `close_site` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO control( `id`, `close_message`, `close_site` ) VALUES
("1","","0");


DROP TABLE exam;

CREATE TABLE `exam` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class` varchar(50) NOT NULL,
  `teacher_name` varchar(50) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `date` varchar(10) NOT NULL,
  `time` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




DROP TABLE index_users;

CREATE TABLE `index_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `index_num` varchar(30) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `type` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO index_users( `id`, `index_num`, `full_name`, `type` ) VALUES
("1","27062040488","administrator","administrator");


DROP TABLE lessons;

CREATE TABLE `lessons` (
  `lesson_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(250) NOT NULL,
  `lesson` text NOT NULL,
  `author` varchar(50) NOT NULL,
  `date` varchar(10) NOT NULL,
  `class` varchar(30) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `jointes` varchar(200) NOT NULL,
  PRIMARY KEY (`lesson_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




DROP TABLE messages;

CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message_from` varchar(30) NOT NULL,
  `name` varchar(50) NOT NULL,
  `subject` varchar(200) NOT NULL,
  `message` mediumtext NOT NULL,
  `date` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




DROP TABLE parents_users;

CREATE TABLE `parents_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(50) NOT NULL,
  `parent_index` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `sex` varchar(10) NOT NULL,
  `address` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




DROP TABLE reports;

CREATE TABLE `reports` (
  `report_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_index` varchar(20) NOT NULL,
  `to_parents` int(2) NOT NULL,
  `author` varchar(50) NOT NULL,
  `title` varchar(250) NOT NULL,
  `report` mediumtext NOT NULL,
  `date` varchar(10) NOT NULL,
  `read_report` int(2) NOT NULL,
  `hide_report` int(2) NOT NULL,
  PRIMARY KEY (`report_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




DROP TABLE reset_pass;

CREATE TABLE `reset_pass` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL,
  `reset_code` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




DROP TABLE students_marks;

CREATE TABLE `students_marks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` varchar(50) NOT NULL,
  `date` varchar(10) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `teacher_name` varchar(50) NOT NULL,
  `mark` varchar(50) NOT NULL,
  `note` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




DROP TABLE students_users;

CREATE TABLE `students_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(250) NOT NULL,
  `registration_num` int(10) NOT NULL,
  `parent_index` varchar(50) NOT NULL,
  `image` varchar(250) NOT NULL,
  `student_index` varchar(50) NOT NULL,
  `username` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `phone` varchar(200) NOT NULL,
  `sex` varchar(20) NOT NULL,
  `address` varchar(250) NOT NULL,
  `birthday` varchar(10) NOT NULL,
  `student_class` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




DROP TABLE subjects;

CREATE TABLE `subjects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject_name` varchar(50) NOT NULL,
  `subject_teacher` varchar(50) NOT NULL,
  `subject_class` varchar(50) NOT NULL,
  `subject_note` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




DROP TABLE teachers_users;

CREATE TABLE `teachers_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(50) NOT NULL,
  `teacher_index` varchar(50) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `sex` varchar(10) NOT NULL,
  `address` varchar(50) NOT NULL,
  `image` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




DROP TABLE topics;

CREATE TABLE `topics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(250) NOT NULL,
  `topic` text NOT NULL,
  `image` varchar(150) NOT NULL,
  `date` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




DROP TABLE transport;

CREATE TABLE `transport` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `day` varchar(20) NOT NULL,
  `time_start_e` varchar(30) NOT NULL,
  `time_return_e` varchar(30) NOT NULL,
  `class_name` varchar(50) NOT NULL,
  `time_start_m` varchar(20) NOT NULL,
  `time_return_m` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




DROP TABLE users_messages;

CREATE TABLE `users_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `author_index` varchar(30) NOT NULL,
  `author_name` varchar(50) NOT NULL,
  `to_index` varchar(30) NOT NULL,
  `type` varchar(30) NOT NULL,
  `subject` varchar(250) NOT NULL,
  `message` mediumtext NOT NULL,
  `date` varchar(10) NOT NULL,
  `msg_read` int(2) NOT NULL,
  `hide_msg` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




SET FOREIGN_KEY_CHECKS=1;
COMMIT;