<?php 
/*======================================================================*\
|| #################################################################### ||
|| #               											          # ||
|| #              EasySchool v1.0 - School management system          # ||
|| #               											          # ||
|| # ---------------------------------------------------------------- # ||
|| #         Copyright © 2016 EasySchool. All Rights Reserved.        # ||
|| # 				    	http://www.dabach.net		     		  # ||
|| #               											          # ||
|| # ---------------- ------------------------------- --------------- # ||
|| #               											          # ||
|| #################################################################### ||
\*======================================================================*/

session_start(); 

if (!isset($_SESSION ['administrator']) && !isset($_SESSION ['admin_index'])) {
  header("location: login.php") ;
}

if (isset($_SESSION ['admin_index'])) {
  $admin_index = $_SESSION ['admin_index'];
}

require '../includes/database_config.php';
include '../includes/display_errors.php';
include '../includes/make_lang.php';

 ?><!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="favicon.png" />

    <title><?php echo $lang ['edit']; ?></title>

    <!-- Bootstrap core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap theme -->
    <link href="../css/bootstrap-theme.min.css" rel="stylesheet">
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="../css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="../js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    
     <link href="../css/style.css" rel="stylesheet">
      <link href="../css/Normalize.css" rel="stylesheet">

      <?php 
     if (isset($_SESSION['arabic'])) {
echo '<link rel="stylesheet" href="../fonts/fr/fonts_css.css">';
      }

      if (isset($_SESSION['francais']) OR isset($_SESSION['english'])) {
      echo '<link rel="stylesheet" href="../fonts/fr/fonts_css.css">';
      }

      ?>

      <script src="../js/jquery-1.11.3.min.js"></script>

      <link rel="stylesheet" href="../libs/validationEngine/validationEngine.jquery.css" type="text/css"/>
<?php 
if (isset($_SESSION['arabic'])) {
    echo '<script src="../libs/validationEngine/languages/jquery.validationEngine-ar.js" type="text/javascript" charset="utf-8"></script>';
}
if (isset($_SESSION['francais'])) {
    echo '<script src="../libs/validationEngine/languages/jquery.validationEngine-fr.js" type="text/javascript" charset="utf-8"></script>';
}

if (isset($_SESSION['english'])) {
    echo '<script src="../libs/validationEngine/languages/jquery.validationEngine-en.js" type="text/javascript" charset="utf-8"></script>';
}  
?>
      <script src="../libs/validationEngine/jquery.validationEngine.js" type="text/javascript" charset="utf-8">
      </script>
      <script>
        jQuery(document).ready(function(){
          // binds form submission and fields to the validation engine
          jQuery("#formID").validationEngine();
          jQuery("#formID2").validationEngine();
        });
 
      </script>
        
  </head>
<body>

<?php include 'nav.php'; ?> 



<div class="container mainbg">
<br><a class="return" href="index.php"><i class="glyphicon glyphicon-arrow-left"></i> <?php echo $lang ['return']; ?></a>

    <h1 class="h1_title"><?php echo $lang ['edit']; ?></h1>
    <hr> <br>

<?php 
if (isset($_GET['update']) == "success") {
  echo "<div class='alert alert-success center' style='width: 90%; margin: auto;'><p>".$lang ['edit_successfully']."</p></div><br><br>"; 
}

if (isset($_GET['error']) == "error") {
  echo "<div class='alert alert-danger center' style='width: 90%; margin: auto;'><p>".$lang ['Error_retry_again']."</p></div><br><br>"; 
}
 ?>

<div class="clear"></div>

<?php 
if (isset($_GET['user'])) {

$user_index = htmlspecialchars($_GET['user']);

$stmt_get_allInfo = $connect->prepare("SELECT * FROM users WHERE user_index=:user_index ");
$stmt_get_allInfo->bindParam (':user_index' , $user_index , PDO::PARAM_STR );
$stmt_get_allInfo->execute();

if ($stmt_get_allInfo->rowCount() !== 1 ) {
  die("<div class='alert alert-danger center' style='width: 90%; margin: auto;'><p>".$lang ['sorry_There_is_no_user_with_this_link']."</p></div><br><br>");
}

$row_allInfo = $stmt_get_allInfo->fetch();

$the_fullname = $row_allInfo ['full_name'];
$the_image = $row_allInfo ['image'];
$the_number = $row_allInfo ['registration_num'];
$the_class = $row_allInfo ['student_class'];
$the_sex = $row_allInfo ['sex'];
$the_birthday = $row_allInfo ['birthday'];
$the_address = $row_allInfo ['address'];
$the_phone = $row_allInfo ['phone'];
$the_email = $row_allInfo ['email'];

$the_img = $row_allInfo ['image'];




/* --------------------------------------------------------------------------------*/


if (isset($_POST['updateinfo'])) {

  $student_fullname = htmlspecialchars($_POST['full_name']);
  $student_type = htmlspecialchars($_POST['type']);
  $student_birthday = htmlspecialchars($_POST['birthday']);
  $student_address = htmlspecialchars($_POST['address']);
  $student_email = htmlspecialchars($_POST['email']);
  $student_phone = htmlspecialchars($_POST['phone']);

  $student_image = "article_img.jpg";


  $stmt_student = $connect->prepare("UPDATE users SET full_name=:full_name, image='$student_image', email=:email, phone=:phone, sex=:sex, address=:address, birthday=:birthday WHERE user_index=:user_index");
  $stmt_student->bindParam (':full_name' , $student_fullname , PDO::PARAM_STR );
  $stmt_student->bindParam (':email' , $student_email , PDO::PARAM_STR );
  $stmt_student->bindParam (':phone' , $student_phone , PDO::PARAM_STR );
  $stmt_student->bindParam (':sex' , $student_type , PDO::PARAM_STR );
  $stmt_student->bindParam (':address' , $student_address , PDO::PARAM_STR );
  $stmt_student->bindParam (':birthday' , $student_birthday , PDO::PARAM_STR );
  $stmt_student->bindParam (':user_index' , $user_index , PDO::PARAM_STR );
  $stmt_student->execute();



  if (isset($stmt_student)) {
    
    echo "<meta http-equiv='refresh' content='0; url = edit.php?user=$user_index&update=success' />"; 
    
  }

  else {
   //echo "<div class='alert alert-danger center' style='width: 90%; margin: auto; margin-top: 50px'><p>error..!</p></div>";    

      
    echo "<meta http-equiv='refresh' content='0; url = edit.php?user=$user_index&error=error' />"; 
  }
  
}


if (isset($_POST['update_password'])) {
   

  $new_pass = htmlspecialchars(md5($_POST['new_pass']));


      $stmt_update_pass = $connect->prepare("UPDATE users SET password=:password WHERE user_index=:user_index");
      $stmt_update_pass->bindParam (':password' , $new_pass , PDO::PARAM_STR );
      $stmt_update_pass->bindParam (':user_index' , $user_index , PDO::PARAM_STR );
      $stmt_update_pass->execute();

      if (isset($stmt_update_pass)) {
      //  header ("location: edit.php?student=$user_index&update=success");   
        echo "<meta http-equiv='refresh' content='0; url = edit.php?user=$user_index&update=success' />"; 

      }

  else {
  // header ("location: edit.php?student=$student_index&error=error");   
    echo "<meta http-equiv='refresh' content='0; url = edit.php?user=$user_index&error=error' />"; 
    
  }


} 

if (isset($_POST['submit_delete'])) {
   
  $stmt_delete = $connect->prepare("DELETE FROM users WHERE user_index=:user_index");
  $stmt_delete->bindParam (':user_index' , $student_index , PDO::PARAM_STR );
  $stmt_delete->execute();

  if (isset($stmt_delete)) {


      if (!empty($the_img)) {
        unlink("../uploads/users/".$the_img);
      }

    header ("location: user.php");   
    echo "<meta http-equiv='refresh' content='0; url = user.php' />"; 
  }

} 


?>

    <div class="clear"></div>

    <div class="row col-md-12 col-md-offset-0">

<form id="formID" action="" method="post">


          <label class=""><?php echo $lang ['full_name']; ?> : <span style="color:red; font-weight: bold; font-family: Arial, sans-serif ;">(*)</span></label>
          <div class="input-group">
              <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
              <input name="full_name" type="text" placeholder="" class="form-control validate[required]" value="<?php echo $the_fullname; ?>"/>
          </div><br>


          <label class=""><?php echo $lang ['gender']; ?> : <span style="color:red; font-weight: bold; font-family: Arial, sans-serif ;">(*)</span></label>
          <div class="input-group">
              <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
              <select name="type" class="form-control validate[required]">
                <option selected="selected" value=""><?php echo $lang ['select']; ?></option>
                <option value="<?php echo $lang ['man']; ?>"><?php echo $lang ['man']; ?></option>
                <option value="<?php echo $lang ['woman']; ?>"><?php echo $lang ['woman']; ?></option>
              </select>
          </div><br>

          <label class=""><?php echo $lang ['birth_date']; ?> : </label>
          <div class="input-group">
              <span class="input-group-addon"><i class="glyphicon glyphicon-time"></i></span>
              <input name="birthday" type="text" placeholder="" class="form-control validate[custom[date]] " value="<?php echo $the_birthday; ?>"/>
          </div><br>

          <label class=""><?php echo $lang ['Address']; ?> : </label>
          <div class="input-group">
              <span class="input-group-addon"><i class="glyphicon glyphicon-globe"></i></span>
              <input name="address" type="text" placeholder="" class="form-control" value="<?php echo $the_address; ?>"/>
          </div><br>

          <label class=""><?php echo $lang ['email']; ?> : </label>
          <div class="input-group">
              <span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
              <input name="email" type="text" placeholder="" class="form-control" value="<?php echo $the_email; ?>"/>
          </div><br>

          <label class=""><?php echo $lang ['phone']; ?> : </label>
          <div class="input-group">
              <span class="input-group-addon"><i class="glyphicon glyphicon-phone"></i></span>
              <input name="phone" type="text" placeholder="" class="form-control" value="<?php echo $the_phone; ?>"/>
          </div><br>      

          <button type="submit" name="updateinfo" class="mybtn mybtn-primary"><?php echo $lang ['save']; ?></button><br><br>
  


 </form>

 <hr>
          <form id="formID2" action="" method="post">

          <div class="info_students"> 
          
              <label class=""><?php echo $lang ['new_password']; ?> : <span style="color:red; font-weight: bold; font-family: Arial, sans-serif ;">(*)</span></label>
              <div class="input-group">
                  <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                  <input name="new_pass" type="password" id="password" class="form-control validate[required]" value=""/>
              </div><br>

              <label class=""><?php echo $lang ['confirm_password']; ?> : <span style="color:red; font-weight: bold; font-family: Arial, sans-serif ;">(*)</span></label>
              <div class="input-group">
                  <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                  <input name="password2" type="password" placeholder="" class="form-control validate[required,equals[password]]" value=""/>
              </div>
          </div><br>  

          <button type="submit" name="update_password" class="mybtn mybtn-primary"><?php echo $lang ['change_password']; ?></button><br>

          </form> <br><br>

  <hr>
          <form id="" action="" method="post" class="center"> 

          <button onclick="return confirm('<?php echo $lang ['delete_user']; ?> !')" type="submit" name="submit_delete" class="btn btn-danger"><?php echo $lang ['delete_student']; ?> </button><br>

          </form> <br><br>

  </div>       

<?php } ?> 










<?php 
if (isset($_GET['company'])) {

$company_index = htmlspecialchars($_GET['company']);

$stmt_get_allInfo = $connect->prepare("SELECT * FROM company WHERE company_index=:company_index ");
$stmt_get_allInfo->bindParam (':company_index' , $company_index , PDO::PARAM_STR );
$stmt_get_allInfo->execute();

if ($stmt_get_allInfo->rowCount() !== 1 ) {
  die("<div class='alert alert-danger center' style='width: 90%; margin: auto;'><p>".$lang ['sorry_There_is_no_user_with_this_link']."</p></div><br><br>");
}

$row_allInfo = $stmt_get_allInfo->fetch();

$the_fullname = $row_allInfo ['full_name'];
$the_image = $row_allInfo ['image'];
$the_subject = $row_allInfo ['subject'];
$the_sex = $row_allInfo ['sex'];
$the_address = $row_allInfo ['address'];
$the_phone = $row_allInfo ['phone'];
$the_email = $row_allInfo ['email'];
$the_img = $row_allInfo ['image'];

/* --------------------------------------------------------------------------------*/


if (isset($_POST['updateinfo'])) {

  $teacher_fullname = htmlspecialchars($_POST['full_name']);
  $teacher_type = htmlspecialchars($_POST['type']);
  $teacher_subject = htmlspecialchars($_POST['subject']);
  $teacher_address = htmlspecialchars($_POST['address']);
  $teacher_email = htmlspecialchars($_POST['email']);
  $teacher_phone = htmlspecialchars($_POST['phone']);

  $teacher_image = "article_img.jpg";


  $stmt_teacher = $connect->prepare("UPDATE company SET full_name=:full_name, image='$teacher_image', email=:email, phone=:phone, sex=:sex, address=:address, subject=:subject WHERE company_index=:company_index");
  $stmt_teacher->bindParam (':full_name' , $teacher_fullname , PDO::PARAM_STR );
  $stmt_teacher->bindParam (':email' , $teacher_email , PDO::PARAM_STR );
  $stmt_teacher->bindParam (':phone' , $teacher_phone , PDO::PARAM_STR );
  $stmt_teacher->bindParam (':sex' , $teacher_type , PDO::PARAM_STR );
  $stmt_teacher->bindParam (':address' , $teacher_address , PDO::PARAM_STR );
  $stmt_teacher->bindParam (':subject' , $teacher_subject , PDO::PARAM_STR );
  $stmt_teacher->bindParam (':company_index' , $teacher_index , PDO::PARAM_STR );
  $stmt_teacher->execute();



  if (isset($stmt_teacher)) {
 
    echo "<meta http-equiv='refresh' content='0; url = edit.php?teacher=$teacher_index&update=success' />"; 
    
  }

  else { 

  
    echo "<meta http-equiv='refresh' content='0; url = edit.php?teacher=$teacher_index&error=error' />"; 
  }
  
}


if (isset($_POST['update_password'])) {
   
  $new_pass = htmlspecialchars(md5($_POST['new_pass']));


      $stmt_update_pass = $connect->prepare("UPDATE company SET password=:password WHERE company_index=:company_index");
      $stmt_update_pass->bindParam (':password' , $new_pass , PDO::PARAM_STR );
      $stmt_update_pass->bindParam (':company_index' , $company_index , PDO::PARAM_STR );
      $stmt_update_pass->execute();

      if (isset($stmt_update_pass)) {
          
        echo "<meta http-equiv='refresh' content='0; url = edit.php?teacher=$teacher_index&update=success' />"; 

      }

  else {
      
    echo "<meta http-equiv='refresh' content='0; url = edit.php?teacher=$teacher_index&error=error' />"; 
    
  }

} 


if (isset($_POST['submit_delete'])) {
   
  $stmt_delete = $connect->prepare("DELETE FROM company WHERE company_index=:company_index");
  $stmt_delete->bindParam (':company_index' , $company_index , PDO::PARAM_STR );
  $stmt_delete->execute();

  if (isset($stmt_delete)) {

    if (!empty($the_img)) {
        unlink("../uploads/company/".$the_img);
      }

    header ("location: company.php");   
    echo "<meta http-equiv='refresh' content='0; url = company.php' />"; 
  }

} 


?>

    <div class="clear"></div>

    <div class="row col-md-12 col-md-offset-0">


<form id="formID" action="" method="post">


          <label class=""><?php echo $lang ['full_name']; ?> : <span style="color:red; font-weight: bold; font-family: Arial, sans-serif ;">(*)</span></label>
          <div class="input-group">
              <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
              <input name="full_name" type="text" placeholder="" class="form-control validate[required]" value="<?php echo $the_fullname; ?>"/>
          </div><br>


        
          <label class=""><?php echo $lang ['subject']; ?> : <span style="color:red; font-weight: bold; font-family: Arial, sans-serif ;">(*)</span></label>
          <div class="input-group">
              <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
              <select name="subject" class="form-control validate[required]">
                <option selected="selected" value=""><th><?php echo $lang ['select']; ?></th></option>
<?php 
  $stmt_find_subject = $connect->query("SELECT * FROM subjects");

  while ($find_subjects_row = $stmt_find_subject->fetch()) {
      $fetch_subject_name = $find_subjects_row ['subject_name'];

      echo '<option value="'.$fetch_subject_name.'">'.$fetch_subject_name.'</option>';

  } 
?>
              </select>
          </div>
          <br>
          <br>

          <label class=""><?php echo $lang ['gender']; ?> : <span style="color:red; font-weight: bold; font-family: Arial, sans-serif ;">(*)</span></label>
          <div class="input-group">
              <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
              <select name="type" class="form-control validate[required]">
                <option selected="selected" value=""><?php echo $lang ['select']; ?></option>
                <option value="<?php echo $lang ['man']; ?>"><?php echo $lang ['man']; ?></option>
                <option value="<?php echo $lang ['woman']; ?>"><?php echo $lang ['woman']; ?></option>
              </select>
          </div><br>


          <label class=""><?php echo $lang ['Address']; ?> : </label>
          <div class="input-group">
              <span class="input-group-addon"><i class="glyphicon glyphicon-globe"></i></span>
              <input name="address" type="text" placeholder="" class="form-control" value="<?php echo $the_address; ?>"/>
          </div><br>

          <label class=""><?php echo $lang ['email']; ?> : </label>
          <div class="input-group">
              <span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
              <input name="email" type="text" placeholder="" class="form-control" value="<?php echo $the_email; ?>"/>
          </div><br>

          <label class=""><?php echo $lang ['phone']; ?> : </label>
          <div class="input-group">
              <span class="input-group-addon"><i class="glyphicon glyphicon-phone"></i></span>
              <input name="phone" type="text" placeholder="" class="form-control" value="<?php echo $the_phone; ?>"/>
          </div><br>      

          <button type="submit" name="updateinfo" class="mybtn mybtn-primary"><?php echo $lang ['save']; ?></button><br><br>
  
  
 </form>

 <hr>

<form id="formID2" action="" method="post">

          <div class="info_teachers"> 
          
              <label class=""><?php echo $lang ['new_password']; ?> : <span style="color:red; font-weight: bold; font-family: Arial, sans-serif ;">(*)</span></label>
              <div class="input-group">
                  <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                  <input name="new_pass" type="password" id="password" class="form-control validate[required]" value=""/>
              </div><br>

              <label class=""><?php echo $lang ['confirm_password']; ?> : <span style="color:red; font-weight: bold; font-family: Arial, sans-serif ;">(*)</span></label>
              <div class="input-group">
                  <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                  <input name="password2" type="password" placeholder="" class="form-control validate[required,equals[password]]" value=""/>
              </div>
          </div><br>  

          <button type="submit" name="update_password" class="mybtn mybtn-primary"><?php echo $lang ['change_password']; ?></button><br>

</form>  <br><br>

<hr>
          <form id="" action="" method="post" class="center"> 

          <button type="submit" onclick="return confirm('<?php echo $lang ['delete_teacher']; ?> !')" name="submit_delete" class="btn btn-danger"><?php echo $lang ['delete_teacher']; ?></button><br>

          </form> <br><br>

</div>

<?php } ?> 








    <div class="clear"></div>

                           
 <?php include 'footer.php'; ?>             

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/docs.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../js/ie10-viewport-bug-workaround.js"></script>



  </body>
</html>
