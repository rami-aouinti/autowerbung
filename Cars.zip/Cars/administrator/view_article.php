<?php 
/*======================================================================*\
|| #################################################################### ||
|| #                                              # ||
|| #              EasySchool v1.0 - School management system          # ||
|| #                                              # ||
|| # ---------------------------------------------------------------- # ||
|| #         Copyright © 2016 EasySchool. All Rights Reserved.        # ||
|| #              http://www.dabach.net             # ||
|| #                                              # ||
|| # ---------------- ------------------------------- --------------- # ||
|| #                                              # ||
|| #################################################################### ||
\*======================================================================*/

session_start(); 

if (!isset($_SESSION ['administrator']) && !isset($_SESSION ['admin_index'])) {
  header("location: login.php") ;
}

if (isset($_SESSION ['admin_index'])) {
  $admin_index = $_SESSION ['admin_index'];
}

require '../includes/database_config.php';
include '../includes/display_errors.php';
include '../includes/make_lang.php';


 ?><!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="favicon.png" />
<?php 


if (isset($_GET['id'])) {

  $get_id = htmlspecialchars($_GET['id']);


  $stmt_topics = $connect->prepare("SELECT * FROM cars WHERE id=:id");
  $stmt_topics->bindParam (':id', $get_id , PDO::PARAM_STR);
  $stmt_topics->execute();

  if ($stmt_topics->rowCount() == 1) {
        $topics_row = $stmt_topics->fetch();

         $topic_id = $topics_row ['id'];
        $topic_title = $topics_row ['title'];
        $topic_marke = $topics_row ['marke'];
        $topic_model = $topics_row ['model'];
        $topic_color = $topics_row ['color'];
        $topic_form = $topics_row ['form'];
        $topic_werbung = $topics_row ['werbung'];
        $topic_places = $topics_row ['places'];
        $topic_baujahr = $topics_row ['baujahr'];
        $topic_image = $topics_row ['image'];
        $topic_date = $topics_row ['date'];
          $topic_user = $topics_row ['user_id'];

        echo '<title>'.$topic_title.'</title>';
    }

    else { echo '<title>404</title>'; }

}
 ?>

    

    <!-- Bootstrap core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap theme -->
    <link href="../css/bootstrap-theme.min.css" rel="stylesheet">
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="../css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="../js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    
     <link rel="stylesheet" href="../css/style.css" rel="stylesheet">
     <link rel="stylesheet" href="../css/Normalize.css" rel="stylesheet">
     <link rel="stylesheet" href="../css/font-awesome/css/font-awesome.min.css">
     
     <?php 
     if (isset($_SESSION['arabic'])) {
echo '<link rel="stylesheet" href="../fonts/fr/fonts_css.css">';
      }

      if (isset($_SESSION['francais']) OR isset($_SESSION['english'])) {
      echo '<link rel="stylesheet" href="../fonts/fr/fonts_css.css">';
      }

      ?>

      <script src="../js/jquery-1.11.3.min.js"></script>
        
  </head>
<body>

<?php include 'nav.php'; ?> 






<div class="container" style="margin-top: 80px;">
  <div class="row">

    <div class="col-md-12 container-1">

<br><a class="return" href="articles.php" style="margin-left:20px;"><i class="glyphicon glyphicon-arrow-left"></i> <?php echo $lang ['return']; ?></a>

<?php 

if (isset($_SESSION ['administrator'])) { ?>

<form action="" method="post">
<button onclick="return confirm('<?php echo $lang ['delete']; ?> !')" type="submit" name="delete_topic" class="btn btn-warning" style="float: right;">
<i class="glyphicon glyphicon-trash"></i> <?php echo $lang ['delete']; ?></button>
</form>

<?php 
  if (isset($_POST['delete_topic'])) {

      $delete_id = $_GET['id'];

      $stmt_delete = $connect->prepare("DELETE FROM cars WHERE id=:id");
      $stmt_delete->bindParam (':id' , $delete_id , PDO::PARAM_STR );
      $stmt_delete->execute();

      if (!empty($topic_img)) {
        unlink("../uploads/topics/".$topic_img);
      }

      if (isset($stmt_delete)) { 
        header ("location: articles.php");
        echo "<meta http-equiv='refresh' content='0; url = articles.php' />";
      }


  } 

}

?>


<div class="clear"></div> 

<?php 

if (!isset($_GET['id'])) {
        die('<br><br><div class="alert alert-danger center" style="width: 90%; margin: auto;"><p>'.$lang ['sorry_There_is_no_topic_with_this_link'].'</p></div><br><br>');
    }

if (isset($_GET['id'])) {

  $get_id = htmlspecialchars($_GET['id']);


  $stmt_topics = $connect->prepare("SELECT * FROM cars WHERE id=:id");
  $stmt_topics->bindParam (':id', $get_id , PDO::PARAM_STR);
  $stmt_topics->execute();

  if ($stmt_topics->rowCount() != 1) {
        die('<br><br><div class="alert alert-danger center" style="width: 90%; margin: auto;"><p>'.$lang ['sorry_There_is_no_topic_with_this_link'].'</p></div><br><br>');
    }


 $topics_row = $stmt_topics->fetch();


         $topic_id = $topics_row ['id'];
        $topic_title = $topics_row ['title'];
        $topic_marke = $topics_row ['marke'];
        $topic_model = $topics_row ['model'];
        $topic_color = $topics_row ['color'];
        $topic_form = $topics_row ['form'];
        $topic_werbung = $topics_row ['werbung'];
        $topic_places = $topics_row ['places'];
        $topic_baujahr = $topics_row ['baujahr'];
        $topic_image = $topics_row ['image'];
        $topic_image1 = $topics_row ['image1'];
        $topic_image2 = $topics_row ['image2'];
        $topic_image3 = $topics_row ['image3'];
        $topic_image4 = $topics_row ['image4'];
        $topic_date = $topics_row ['date'];
          $topic_user = $topics_row ['user_id'];

 ?>
<div class="clear"></div>
            <div class="single">

                <div class="single_header">

                  <h2><?php echo $topic_title; ?></h2>  

                  <span><i class="glyphicon glyphicon-time"></i> <?php echo $topic_date; ?></span>

                </div>

                <div class="clear"></div>

                 <br>
                <div class="row">
                  <div class="col-md-6">
                    <p><strong> Marke : </strong> <?php echo $topic_marke; ?> </p>
                     <p><strong> Modell :</strong>   <?php echo $topic_model; ?></p>
                      <p><strong> Color : </strong> <?php echo $topic_color; ?></p>
                       <p><strong> Carosserieform :</strong>  <?php echo $topic_form; ?></p>
                        <p><strong> Werbungstyp : </strong> <?php echo $topic_werbung; ?></p>
                         <p><strong> Places :</strong>  <?php echo $topic_places; ?></p>
                          <p><strong> Baujahr : </strong> <?php echo $topic_baujahr; ?></p>
                  </div>


       <div class="col-md-6">

  <div class="row">
                    <div class="col-md-3">
                    <a href="view_article.php?id=<?php echo $topic_id; ?>">
                         <?php 

                         if (!empty($topic_image)) {
                          echo '<img src="../uploads/new_cars/'.$topic_image.'" alt="..." class="img-thumbnail" height="" width="100%">';
                        }

                       if (!empty($topic_image1)) {
                          echo '<img src="../uploads/new_cars1/'.$topic_image1.'" alt="..." class="img-thumbnail" height="" width="100%">';
                        }


                         if (!empty($topic_image2)) {
                          echo '<img src="../uploads/new_cars2/'.$topic_image2.'" alt="..." class="img-thumbnail" height="" width="100%">';
                        }



                         if (!empty($topic_image3)) {
                          echo '<img src="../uploads/new_cars3/'.$topic_image3.'" alt="..." class="img-thumbnail" height="" width="100%">';
                        }



                         if (!empty($topic_image4)) {
                          echo '<img src="../uploads/new_cars4/'.$topic_image4.'" alt="..." class="thumbnail" height="" width="100%">';
                        }

                        ?> 
                      </a>
            
                  </div>





                </div>


 </div>


                <div class="clear"></div> 

 <a href="message_article.php?id=<?php echo $topic_user; ?>" class="btn btn-default new_lesson"><i class="glyphicon glyphicon-envelope"></i> <?php echo $lang ['contact']; ?></a>


          </div>

<?php } ?><br>

    </div>  
  </div>
</div>        

<?php include 'footer.php'; ?>  

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/docs.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../js/ie10-viewport-bug-workaround.js"></script>



  </body>
</html>
