<div id="footer">
  Copyright &copy; <?php echo date("Y"); ?> | Autowerbung -Mohamed Rami Aouinti  
</div>   