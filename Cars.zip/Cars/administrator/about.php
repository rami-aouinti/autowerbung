<?php 
/*======================================================================*\
|| #################################################################### ||
|| #               											          # ||
|| #              EasySchool v1.0 - School management system          # ||
|| #               											          # ||
|| # ---------------------------------------------------------------- # ||
|| #         Copyright © 2016 EasySchool. All Rights Reserved.        # ||
|| # 				    	http://www.dabach.net		     		  # ||
|| #               											          # ||
|| # ---------------- ------------------------------- --------------- # ||
|| #               											          # ||
|| #################################################################### ||
\*======================================================================*/

session_start(); 

if (!isset($_SESSION ['administrator']) && !isset($_SESSION ['admin_index'])) {
  header("location: login.php") ;
}

if (isset($_SESSION ['admin_index'])) {
  $admin_index = $_SESSION ['admin_index'];
}

require '../includes/database_config.php';
include '../includes/display_errors.php';
include '../includes/make_lang.php';

 ?><!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="favicon.png" />

    <title><?php echo $lang ['about_us']; ?></title>

    <!-- Bootstrap core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap theme -->
    <link href="../css/bootstrap-theme.min.css" rel="stylesheet">
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="../css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="../js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    
     <link href="../css/style.css" rel="stylesheet">
      <link href="../css/Normalize.css" rel="stylesheet">
     <?php 
     if (isset($_SESSION['arabic'])) {
echo '<link rel="stylesheet" href="../fonts/fr/fonts_css.css">';
      }

      if (isset($_SESSION['francais']) OR isset($_SESSION['english'])) {
      echo '<link rel="stylesheet" href="../fonts/fr/fonts_css.css">';
      }

      ?>

      <script src="../js/jquery-1.11.3.min.js"></script>
        
  </head>
<body>

<?php include 'nav.php'; ?> 

<div class="container mainbg">

<br><a class="return" href="index.php"><i class="glyphicon glyphicon-arrow-left"></i> <?php echo $lang ['return']; ?></a>

    <h1 class="h1_title"><?php echo $lang ['about_us']; ?></h1>

<hr> 

<div class="easyschool">
  <img src="../images/klakwerbung.png" />
</div>


<div class="clear"></div>


<?php if (isset($_SESSION['arabe'])) { ?>

<p class="about_p">Die kreative Full-Service Werbeagentur für Online- und Printprodukte in Berlin-Friedrichshagen. </p>
<br>

<p class="about_p">Klak Werbung ist seit über 20 Jahren in Friedrichshagen als zuverlässiger Dienstleister bekannt. Die Gründer Karin und Klaus Böhme legten den Grundstein für eine regionale Partnerschaft in Sachen Außen- und Kfz-Werbung. Durch die Zusammenlegung mit der Kreativagentur Creative AdIT wurde das Portfolio um Webprodukte, Hosting und eCommerce erweitert. Wir bieten unseren Kunden maßgeschneiderte Kampagnen, Corparate Identities und Designs für Web- und Printprodukte.  Besonders stolz sind wir auf das Angebot von Imagefilmen, um auch Ihr Geschäft in den Fokus zu rücken. In der Bölschestraße in Berlin-Friedrichshagen können Sie uns aber nicht nur für Werbedienstleistungen besuchen. Als GLS- und Copyshop sind wir die regionale Anlaufstelle für Kopieraufträge, Broschüren, Laminierung und weiteres. Durch die Etablierung Friedrichshagener Logos und Anbieter von Souvenirs aus Friedrichshagen finden auch Anwohner und Touristen stets neue attraktive Artikel rund um den Müggelsee. Unser besonderes Highlight ist der Bereich Eventfotografie, bei dem wir durch Fotomontage Träume wahr werden lassen. Besuchen Sie uns mit Ihren Kindern oder überraschen Sie Ihre/n Liebste/n mit einem Geschenk der besonderen Art, was Sie so nirgends in Berlin finden werden. </p>

<br>

<?php } ?>

<?php if (isset($_SESSION['francais'])) { ?>

<p class="about_p">Die kreative Full-Service Werbeagentur für Online- und Printprodukte in Berlin-Friedrichshagen. </p>
<br>

<p class="about_p">Klak Werbung ist seit über 20 Jahren in Friedrichshagen als zuverlässiger Dienstleister bekannt. Die Gründer Karin und Klaus Böhme legten den Grundstein für eine regionale Partnerschaft in Sachen Außen- und Kfz-Werbung. Durch die Zusammenlegung mit der Kreativagentur Creative AdIT wurde das Portfolio um Webprodukte, Hosting und eCommerce erweitert. Wir bieten unseren Kunden maßgeschneiderte Kampagnen, Corparate Identities und Designs für Web- und Printprodukte.  Besonders stolz sind wir auf das Angebot von Imagefilmen, um auch Ihr Geschäft in den Fokus zu rücken. In der Bölschestraße in Berlin-Friedrichshagen können Sie uns aber nicht nur für Werbedienstleistungen besuchen. Als GLS- und Copyshop sind wir die regionale Anlaufstelle für Kopieraufträge, Broschüren, Laminierung und weiteres. Durch die Etablierung Friedrichshagener Logos und Anbieter von Souvenirs aus Friedrichshagen finden auch Anwohner und Touristen stets neue attraktive Artikel rund um den Müggelsee. Unser besonderes Highlight ist der Bereich Eventfotografie, bei dem wir durch Fotomontage Träume wahr werden lassen. Besuchen Sie uns mit Ihren Kindern oder überraschen Sie Ihre/n Liebste/n mit einem Geschenk der besonderen Art, was Sie so nirgends in Berlin finden werden. </p>

<br>

<?php } ?>

<?php if (isset($_SESSION['english'])) { ?>

<p class="about_p">Die kreative Full-Service Werbeagentur für Online- und Printprodukte in Berlin-Friedrichshagen. </p>
<br>

<p class="about_p">Klak Werbung ist seit über 20 Jahren in Friedrichshagen als zuverlässiger Dienstleister bekannt. Die Gründer Karin und Klaus Böhme legten den Grundstein für eine regionale Partnerschaft in Sachen Außen- und Kfz-Werbung. Durch die Zusammenlegung mit der Kreativagentur Creative AdIT wurde das Portfolio um Webprodukte, Hosting und eCommerce erweitert. Wir bieten unseren Kunden maßgeschneiderte Kampagnen, Corparate Identities und Designs für Web- und Printprodukte.  Besonders stolz sind wir auf das Angebot von Imagefilmen, um auch Ihr Geschäft in den Fokus zu rücken. In der Bölschestraße in Berlin-Friedrichshagen können Sie uns aber nicht nur für Werbedienstleistungen besuchen. Als GLS- und Copyshop sind wir die regionale Anlaufstelle für Kopieraufträge, Broschüren, Laminierung und weiteres. Durch die Etablierung Friedrichshagener Logos und Anbieter von Souvenirs aus Friedrichshagen finden auch Anwohner und Touristen stets neue attraktive Artikel rund um den Müggelsee. Unser besonderes Highlight ist der Bereich Eventfotografie, bei dem wir durch Fotomontage Träume wahr werden lassen. Besuchen Sie uns mit Ihren Kindern oder überraschen Sie Ihre/n Liebste/n mit einem Geschenk der besonderen Art, was Sie so nirgends in Berlin finden werden.</p>
<br>

<?php } ?>





<hr>

<p class="center ltr">Copyright &copy; <?php echo date("Y"); ?> | Autowerbung - Mohamed Rami Aouinti<br>  </a></p>

</div>		
                           
 <?php include 'footer.php'; ?>             

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/docs.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../js/ie10-viewport-bug-workaround.js"></script>



  </body>
</html>
